const express = require("express");
const app = express();

app.get("/", function(req, res){
  res.send("Whatsup welcome to calculator");  
});

app.listen(3000, function(){
  console.log("server started at log 3000");
});