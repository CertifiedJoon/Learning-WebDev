const superheroes = require('superheroes');
const supervillains = require('supervillains');
console.log(superheroes.random() + " vs " + supervillains.random());